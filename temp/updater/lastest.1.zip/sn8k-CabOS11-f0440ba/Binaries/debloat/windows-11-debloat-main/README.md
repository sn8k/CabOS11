# Windows 11 Debloater 🚀

This script will be re-designed. 

⚠️ DISCLAIMER: You're using this at your own risk, I'm not responsible for any damage or data loss.

# How to use?

To start this script, run ``Launch.bat`` as Administrator!
